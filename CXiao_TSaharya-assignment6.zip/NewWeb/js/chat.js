var chatBody = document.getElementById('chatBody');
chatBody.scrollTo = chatBody.innerHeight;

console.log(chatBody, chatBody.scrollHeight);
