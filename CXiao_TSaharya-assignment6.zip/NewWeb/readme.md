## For Course Project

Tarun Saharya (ts4pe)
Chufan Xiao (cx7ga)

You can create an account by signing up.
You can log into that account on the login page.
You can see all users on the leaderboard page (additional information in the leaderboard table, like scores, will be added later)
